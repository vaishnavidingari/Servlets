package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/heml");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("password");
		String mailid=request.getParameter("mailid");
		String contact=request.getParameter("contact");
		out.println("<html>");
		out.println("<body bgcolor='skyblue'>");
		out.println("<p>welcome Ms." + username + "</p>");
		out.println("<p>you entered password:" + password + "</p>");
		out.println("<p>you entered mailid:" + mailid + "</p>");
		out.println("<p>you entered contact no:" + contact + "</p>");
		out.println("<body>");
		out.println("<html>");
		
	}

}
