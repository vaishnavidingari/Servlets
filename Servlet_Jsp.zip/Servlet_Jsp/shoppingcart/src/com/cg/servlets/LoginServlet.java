package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/heml");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("password");
		/*out.println("<html>");
		out.println("<body bgcolor='skyblue'>");
		out.println("<p>welcome Ms." + username + "</p>");
		out.println("<p>you entered password:" + password + "</p>");
		out.println("<body>");
		out.println("<html>");*/
		if(username.equals("vaishnavi") && password.equals("123")){
			RequestDispatcher rd=request.getRequestDispatcher("welcome.jsp");
					rd.forward(request, response);
		}else{
			out.println("<b style='color:red'>user is not registered.please register</b>");
			RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
			rd.include(request, response);
		}
		
				
	}

}
